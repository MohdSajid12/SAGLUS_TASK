<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.min.js"></script>
</head>
<body ng-app="myApp">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <h1 class="text-center">Welcome to Student Dashboard</h1>

                <div ng-controller="studentCtrl" class="panel panel-primary">
                    <div class="panel-heading">
                        <h2 class="panel-title">Your Details are</h2>
                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <td>Name:</td>
                                    <td><?php echo $studentDetails['name']; ?></td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td><?php echo $studentDetails['email']; ?></td>
                                </tr>
                                <tr>
                                    <td>Phone:</td>
                                    <td><?php echo $studentDetails['phone']; ?></td>
                                </tr>
                                <tr>
                                    <td>Password:</td>
                                    <td><?php echo $studentDetails['password']; ?></td>
                                </tr>
                                <tr>
                                    <td>Facebook-Url:</td>
                                    <td><?php echo $studentDetails['fb']; ?></td>
                                </tr>
                            </tbody>
                        </table>

                        <?php if ($adminDetails): ?>
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h2 class="panel-title">Details of your Admin</h2>
                                </div>
                                <div class="panel-body">
                                    <p>Admin Name: <?php echo $adminDetails['firstname']; ?></p>
                                    <p>Admin Email: <?php echo $adminDetails['email']; ?></p>
                                </div>
                            </div>
                        <?php else: ?>
                            <p>No admin details found.</p>
                        <?php endif; ?>

                        <button ng-click="logout()" class="btn btn-danger btn-block">Logout</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var app = angular.module("myApp", ['ngRoute']);

        app.controller("studentCtrl", ['$scope', '$window', '$http', function ($scope, $window, $http) {
            // Logout
            $scope.logout = function () {
                $http.post("Login/logout")
                    .then(function (response) {
                        if (response.data.success) {
                            $window.location.href = "Signup";
                        } else {
                            console.error("Logout failed:", response.data.message);
                        }
                    })
                    .catch(function (error) {
                        console.error("Logout error:", error);
                    });
            };
        }]);
    </script>

</body>
</html>
