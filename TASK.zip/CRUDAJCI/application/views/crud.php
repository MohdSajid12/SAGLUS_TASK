<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.min.js"></script>


</head>

<body ng-app="crudApp" ng-controller="crudController">
    <div class="container" align="center">

        <!-- Add Modal -->
        <div id="addModal" class="modal" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New Student</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form ng-submit="createRecord()">
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" class="form-control" id="name" ng-model="name">
                                <small class="form-text f-14 text-left vi-red-clr" ng-bind-html="trustedHtml(errors.name)" style="color:red"></small>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" ng-model="email">
                                <small class="form-text f-14 text-left vi-red-clr" ng-bind-html="trustedHtml(errors.email)" style="color:red"></small>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                <input type="phone" class="form-control" id="phone" ng-model="phone">
                                <small class="form-text f-14 text-left vi-red-clr" ng-bind-html="trustedHtml(errors.phone)" style="color:red"></small>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="text" class="form-control" id="password" ng-model="password">
                                <small class="form-text f-14 text-left vi-red-clr" ng-bind-html="trustedHtml(errors.password)" style="color:red"></small>
                            </div>
                            <div class="form-group">
                                <label for="fb">Facebook profile link:</label>
                                <input type="url" class="form-control" id="fb" ng-model="fb">
                                <small class="form-text f-14 text-left vi-red-clr" ng-bind-html="trustedHtml(errors.fb)" style="color:red"></small>
                            </div>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>




        <h2>Students Data</h2>

        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" style="margin-right:90%">Add Student</button>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Password</th>
                    <th>Facebook link</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="record in submittedData">
                    <td>{{ record.id }}</td>
                    <td>{{ record.name }}</td>
                    <td>{{ record.email }}</td>
                    <td>{{ record.phone }}</td>
                    <td>{{ record.password }}</td>
                    <td>{{ record.fb }}</td>
                    <td>
                        <button ng-click="openEditModal(record)" class="btn btn-success">Edit</button>
                        <button ng-click="deleteRecord(record)" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
            </tbody>
        </table>

        <div id="editModal" class="modal" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Record</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form ng-submit="updateRecord()">
                            <div class="form-group">
                                <input type="hidden" id="id" ng-model="id">
                            </div>
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" class="form-control" id="name" ng-model="editedName">
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" ng-model="editedEmail">
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                <input type="phone" class="form-control" id="phone" ng-model="editedPhone">
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="text" class="form-control" id="password" ng-model="editedPassword">
                            </div>
                            <div class="form-group">
                                <label for="fb">FB link:</label>
                                <input type="url" class="form-control" id="fb" ng-model="editedFb">
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="text-center">
    <button ng-click="logout()" class="btn btn-primary">Logout</button>
</div>



    <script>
        var app = angular.module('crudApp', []);

        var $config = {
            'base_url': '<?php echo $this->config->item("base_url") ?>'
        }


        app.controller('crudController', ['$scope', '$http', '$sce', '$timeout', function($scope, $http, $sce, $timeout){


            $scope.trustedHtml = function(plainText) {
                return $sce.trustAsHtml(plainText);
            };

            $scope.errors = {};
            $scope.submittedData = [];
            $scope.editedName = '';
            $scope.editedEmail = '';
            $scope.editedPhone = '';
            $scope.editedPassword = '';
            $scope.editedFb = '';
            $scope.editIndex = -1;

            $scope.createRecord = function() {
                var data = $.param({
                    'name': $scope.name,
                    'email': $scope.email,
                    'phone': $scope.phone,
                    'password': $scope.password,
                    'fb': $scope.fb
                });

                $http({
                    method: 'POST',
                    url: $config.base_url + 'Crud/create',
                    data: data,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                    }
                }).then(function(response) {
                    if (response.data && response.data.errors) {
                        $scope.errors = response.data.errors;
                        $timeout(function() {
                            $scope.errors = null;
                        }, 3000); 
                    } else {
                        // If there are no errors, show a success message
                        alert('Data submitted');
                        $scope.name = '';
                        $scope.email = '';
                        $scope.phone = '';
                        $scope.password = '';
                        $scope.fb = '';
                        $scope.getSubmittedData(); // Retrieve updated data
                        $('#addModal').modal('hide');
                    }
                }).catch(function(error) {
                    // Handle HTTP request errors
                    console.log('Error:', error);
                });
            };


            $scope.getSubmittedData = function() {
                $http({
                    method: 'GET',
                    url: $config.base_url + 'Crud/getData',
                }).then(function(response) {
                    console.log('Data fetched successfully:', response.data);
                    $scope.submittedData = response.data;
                }).catch(function(error) {
                    console.log('Error fetching data:', error);
                });
            };


            $scope.openEditModal = function(record) {
                $scope.editIndex = $scope.submittedData.indexOf(record);
                $scope.id = record.id;
                $scope.editedName = record.name;
                $scope.editedEmail = record.email;
                $scope.editedPhone = record.phone;
                $scope.editedPassword = record.password;
                $scope.editedFb = record.fb;

                $('#editModal').modal('show');
            }

            $scope.updateRecord = function() {
                var editedData = {
                    'id': $scope.id,
                    'name': $scope.editedName,
                    'email': $scope.editedEmail,
                    'phone': $scope.editedPhone,
                    'password': $scope.editedPassword,
                    'fb': $scope.editedFb
                };
                var data = $.param(editedData);
                $http({
                    method: 'POST',
                    url: $config.base_url + 'Crud/update',
                    data: data,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                    }
                }).then(function(response) {
                    alert('Record updated');
                    $scope.editedName = '';
                    $scope.editedEmail = '';
                    $scope.editedPhone = '';
                    $scope.editedPassword = '';
                    $scope.editedFb = '';
                    $scope.editIndex = -1;
                    $('#editModal').modal('hide');
                    $scope.getSubmittedData(); // Retrieve updated data
                }).catch(function(error) {
                    console.log('Error:', error);
                });
            }

            $scope.deleteRecord = function(record) {
                var confirmation = confirm('Are you sure you want to delete this record?');
                if (confirmation) {
                    var data = $.param({
                        'id': record.id
                        // 'name': record.name,
                        // 'email': record.email
                    });
                    $http({
                        method: 'POST',
                        url: $config.base_url + 'Crud/delete',
                        data: data,
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                        }
                    }).then(function(response) {
                        alert('Record deleted');
                        $scope.getSubmittedData(); // Retrieve updated data
                    }).catch(function(error) {
                        console.log('Error:', error);
                    });
                }
            }

            $scope.getSubmittedData();


            $scope.logout = function() {
                $http({
                    method: 'GET',
                    url: $config.base_url + 'Login/logout',
                }).then(function(response) {
                    window.location.href = "<?php echo base_url('Signup') ?>"
                }).catch(function(error) {
                    console.log('Error:', error);
                });
            }

        }]);
    </script>

</body>

</html>