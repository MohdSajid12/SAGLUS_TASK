<?php
class frontPageModel extends CI_Model
{
    public function addUser($userData)
    {
        $this->db->insert('signup', $userData);
        return $this->db->insert_id();
    }

    public function checkUser($userData)
    {
        $query = $this->db->get_where('signup', $userData);
        if ($query->num_rows())
        {
            return $query->row();
        } else {
            return false;
        }
    }

    public function insertRecord($data)
    {
        // Before inserting, get the admin details from the session
        $adminId = $this->session->userdata('id');
        
        $modelInstance = new frontPageModel();
        
        // Fetch the admin name using the admin ID through the instance
        $adminDetails = $modelInstance->getAdminDetails($adminId);
        $adminName = $adminDetails['firstname'];
        
        // Add the admin details to the student record data
        $data['admin_id'] = $adminId;
         $data['added_by'] = $adminName;
    
        // Insert the student record into the 'students' table
        return $this->db->insert('students', $data);
    }
    

    public function getRecords($adminId)
    {
        $this->db->where('admin_id', $adminId);
        $q = $this->db->get('students');
        $results = $q->result_array();
        return $results;
    }

    public function updateRecord($data)
    {
        $this->db->where('id', $data['id']);
        return $this->db->update('students', $data);
    }

    public function deleteRecord($data)
    {
        $this->db->where('id', $data['id']);
        return $this->db->delete('students');
    }

    public function authenticate($email, $password)
{
    $this->load->database();

    // Check if the user is an admin
    $this->db->select('id, password');
    $this->db->where('email', $email);
    $admin_query = $this->db->get('signup');

    if ($admin_query->num_rows() > 0) {
        $admin_row = $admin_query->row();
        $hashedPassword = $admin_row->password;

        if (md5($password) === $hashedPassword) {
            $this->session->set_userdata('user_type', 'admin');
            $this->session->set_userdata('id', $admin_row->id); // Store admin ID in session for later use
            return 'admin'; // Return 'admin' to indicate admin login
        } else {
            return false; // Return false for invalid password
        }
    } else {
        //  if the user is a student
        $this->db->select('id, password');
        $this->db->where('email', $email);
        $student_query = $this->db->get('students');

        if ($student_query->num_rows() > 0) {
            $student_row = $student_query->row();
            $student_password = $student_row->password;

            if ($password === $student_password) {
                $this->session->set_userdata('user_type', 'student');
                $this->session->set_userdata('id', $student_row->id);
                return 'student'; // Return 'student' to indicate student login
            } else {
                return false; 
            }
        } else {
            return 'not_found';
        }
    }
}

public function getAdminDetails($adminId)
    {
        $this->db->where('id', $adminId);
        $query = $this->db->get('signup');

        if ($query->num_rows() > 0) {
            $adminDetails = $query->row_array();
            return $adminDetails;
        } else {
            return null;
        }
    }

public function getStudentRecord($studentId)
{
    $this->db->where('id', $studentId);
    $query = $this->db->get('students');

    if ($query->num_rows() > 0) {
        return $query->row_array();
    } else {
        return null;
    }
}

public function getStudentsAddedByAdmin($adminId)
{
    $this->db->where('admin_id', $adminId);

    $q = $this->db->get('students');
        $results = $q->result_array();
        return $results;

}
}
?>