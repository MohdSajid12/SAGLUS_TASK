<?php
class Crud extends CI_Controller
{
public function index()
{
    $userType = $this->session->userdata('user_type');

    if ($userType === 'admin') {
        // Load the existing CRUD view for admins
        // But first, get the currently logged-in admin's ID
        $adminId = $this->session->userdata('id');

        // Get the students added by the currently logged-in admin
        $data['students'] = $this->frontPageModel->getStudentsAddedByAdmin($adminId);
        $this->load->view('crud', $data);
    } 
    else if
     ($userType === 'student') {
        // Load the student dashboard view for students
        $studentId = $this->session->userdata('id');
        $data['studentDetails'] = $this->frontPageModel->getStudentRecord($studentId);

        // Get the admin details using the admin ID stored in the student record
        if (isset($data['studentDetails']['admin_id'])) {
            $data['adminDetails'] = $this->frontPageModel->getAdminDetails($data['studentDetails']['admin_id']);
        }
        // passing $data to the view
        $this->load->view('StudentPage', $data);
    } else {
        // Redirect to the login page or display an error message for unauthenticated users
        redirect('Signup');
    }
}


public function create()
{
    $this->form_validation->set_rules('name', 'Name', 'required'); 
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[students.email]');

    $this->form_validation->set_rules('phone', 'Phone', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required');
    $this->form_validation->set_rules('fb', 'Facebook', 'required');
    
    if ($this->form_validation->run() === FALSE) {
        $errors['name'] = form_error('name', '', '');
        $errors['email'] = form_error('email', '', '');
        $errors['phone'] = form_error('phone', '', '');
        $errors['password'] = form_error('password', '', '');
        $errors['fb'] = form_error('fb', '', '');
        echo json_encode(array('success' => false, 'errors' => $errors));
        return;
    } else
    {
           
        $response = array('status' => 'error', 'message' => 'Failed to login', 'errors' => array());

    $data = array(
        'name' => $this->input->post('name'),
        'email' => $this->input->post('email'),
        'phone' => $this->input->post('phone'),
        'password' => $this->input->post('password'),
        'fb' => $this->input->post('fb'),
    );

    $insert = $this->frontPageModel->insertRecord($data);

    if ($insert) {
        echo "data submitted";
    } else {
        echo "something went wrong";
    }
    }
    echo json_encode(array('success' => true));
}

    public function getData()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $adminId = $this->session->userdata('id'); 
        $data = $this->frontPageModel->getRecords($adminId);
        echo json_encode($data);
    }

    public function update()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $data = array(
            'id' => $this->input->post('id'),
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'phone' => $this->input->post('phone'),
            'password' => $this->input->post('password'),
            'fb' => $this->input->post('fb')
        );

        $update = $this->frontPageModel->updateRecord($data);

        if ($update) {
            echo "record updated";
        } else {
            echo "something went wrong";
        }
    }

    public function delete()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST');
        header('Access-Control-Allow-Headers: Content-Type');

        $data = array(
            'id' => $this->input->post('id'),
        );

        $delete = $this->frontPageModel->deleteRecord($data);

        if ($delete) {
            echo "record deleted";
        } else {
            echo "something went wrong";
        }
    }
}
?>