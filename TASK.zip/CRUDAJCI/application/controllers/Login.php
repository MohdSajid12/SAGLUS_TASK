<?php
class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }
    public function loginUser()
    {

        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $response = array(
            'status' => 'error',
            'message' => 'Validation Error',
            'errors' => array()
        );

        if ($this->form_validation->run() == FALSE) {
            $response['errors'] = $this->form_validation->error_array();
        }
        else
        {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $userData = $this->frontPageModel->authenticate($email, $password);


        $response = array('status' => 'error', 'message' => 'Failed to login', 'errors' => array());

        if ($userData === 'admin') {
            $response['status'] = 'success';
            $response['user_type'] = 'admin';
            $response['success_message'] = 'Login Successful';
        } else if ($userData === 'student') {
            $response['status'] = 'success';
            $response['user_type'] = 'student';
            $response['success_message'] = 'Login Successful';
        } else {
            $response['errors']['login'] = 'Invalid email or password';
        }
    }

        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }

    public function logout()
    {
        $this->session->sess_destroy();
        $response = array('success' => true); // Add a success response
        echo json_encode($response);
    }
}
?>